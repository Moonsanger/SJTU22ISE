import sys
import serial
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QFormLayout, QLabel, QPushButton, QSlider, QLineEdit, QComboBox, QMessageBox, QGroupBox

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("机械臂控制")
        self.setGeometry(100, 100, 1200, 800)

        self.serial_port = None

        # 主窗口布局
        main_layout = QVBoxLayout()

        # 示教区 - 关节坐标
        teach_area = QWidget()
        teach_layout = QVBoxLayout()
        teach_area.setLayout(teach_layout)

        joint_label = QLabel("关节坐标")
        teach_layout.addWidget(joint_label)
        self.joint_x_input = QLineEdit(placeholderText="A1角度(-160~160)")
        self.joint_y_input = QLineEdit(placeholderText="A2角度(-100~0)")
        self.joint_z_input = QLineEdit(placeholderText="A3角度(-115~0)")
        teach_layout.addWidget(self.joint_x_input)
        teach_layout.addWidget(self.joint_y_input)
        teach_layout.addWidget(self.joint_z_input)

        send_joint_button = QPushButton("发送关节数据")
        send_joint_button.clicked.connect(self.send_joint_data)
        teach_layout.addWidget(send_joint_button)
        main_layout.addWidget(teach_area)

        # 配方&反馈区 - 显示当前角度和世界坐标
        feedback_area = QWidget()
        feedback_layout = QVBoxLayout()
        feedback_area.setLayout(feedback_layout)
        angle_label = QLabel("当前角度")
        world_label = QLabel("世界坐标")
        feedback_layout.addWidget(angle_label)
        feedback_layout.addWidget(world_label)
        main_layout.addWidget(feedback_area)

        # 运行区 - 进度条及运行/停止按钮（可扩展）
        run_area = QWidget()
        run_layout = QVBoxLayout()
        run_area.setLayout(run_layout)
        self.progress_bar = QProgressBar()
        run_layout.addWidget(self.progress_bar)
        run_button = QPushButton("运行")
        stop_button = QPushButton("停止")
        run_layout.addWidget(run_button)
        run_layout.addWidget(stop_button)
        main_layout.addWidget(run_area)

        # 设置区 - 速度设置
        settings_area = QWidget()
        settings_layout = QVBoxLayout()
        settings_area.setLayout(settings_layout)
        self.total_speed_slider = QSlider()
        self.total_speed_slider.setRange(0, 100)
        settings_layout.addWidget(QLabel("总速度"))
        settings_layout.addWidget(self.total_speed_slider)
        self.sub_speed_slider = QSlider()
        self.sub_speed_slider.setRange(0, 100)
        settings_layout.addWidget(QLabel("分速度"))
        settings_layout.addWidget(self.sub_speed_slider)
        main_layout.addWidget(settings_area)

        # 外设区 - DI/DO状态显示
        peripheral_area = QWidget()
        peripheral_layout = QVBoxLayout()
        peripheral_area.setLayout(peripheral_layout)
        di_label = QLabel("DI号及状态")
        do_label = QLabel("DO号及状态")
        peripheral_layout.addWidget(di_label)
        peripheral_layout.addWidget(do_label)
        main_layout.addWidget(peripheral_area)

        # 码垛显示区
        stacking_area = QWidget()
        stacking_layout = QVBoxLayout()
        stacking_area.setLayout(stacking_layout)
        stacking_label = QLabel("码垛值: 0")
        stacking_layout.addWidget(stacking_label)
        main_layout.addWidget(stacking_area)

        # 串口控制区
        port_control_area = QWidget()
        port_control_layout = QVBoxLayout()
        port_control_area.setLayout(port_control_layout)
        self.port_combo = QComboBox()
        self.port_combo.addItems(self.list_serial_ports())
        port_control_layout.addWidget(QLabel("选择串口"))
        port_control_layout.addWidget(self.port_combo)
        open_port_button = QPushButton("打开串口")
        close_port_button = QPushButton("关闭串口")
        open_port_button.clicked.connect(self.open_serial_port)
        close_port_button.clicked.connect(self.close_serial_port)
        port_control_layout.addWidget(open_port_button)
        port_control_layout.addWidget(close_port_button)
        main_layout.addWidget(port_control_area)

        # 运动功能区
        motion_area = QGroupBox("运动功能区")
        motion_layout = QGridLayout()
        motion_area.setLayout(motion_layout)

        # 关节角度偏移
        motion_layout.addWidget(QLabel("关节角度偏移"), 0, 0)
        self.joint_offset_x_input = QLineEdit(placeholderText="A1偏移")
        self.joint_offset_y_input = QLineEdit(placeholderText="A2偏移")
        self.joint_offset_z_input = QLineEdit(placeholderText="A3偏移")
        motion_layout.addWidget(self.joint_offset_x_input, 0, 1)
        motion_layout.addWidget(self.joint_offset_y_input, 0, 2)
        motion_layout.addWidget(self.joint_offset_z_input, 0, 3)
        send_joint_offset_button = QPushButton("发送关节偏移")
        send_joint_offset_button.clicked.connect(self.send_joint_offset_data)
        motion_layout.addWidget(send_joint_offset_button, 0, 4)

        # 笛卡尔坐标走点（世界坐标）
        motion_layout.addWidget(QLabel("世界坐标"), 1, 0)
        self.world_x_input = QLineEdit(placeholderText="X坐标")
        self.world_y_input = QLineEdit(placeholderText="Y坐标")
        self.world_z_input = QLineEdit(placeholderText="Z坐标")
        motion_layout.addWidget(self.world_x_input, 1, 1)
        motion_layout.addWidget(self.world_y_input, 1, 2)
        motion_layout.addWidget(self.world_z_input, 1, 3)
        send_world_point_button = QPushButton("发送世界坐标")
        send_world_point_button.clicked.connect(self.send_descartes_point)
        motion_layout.addWidget(send_world_point_button, 1, 4)

        # 笛卡尔坐标点偏移（世界偏移）
        motion_layout.addWidget(QLabel("世界偏移"), 2, 0)
        self.world_offset_x_input = QLineEdit(placeholderText="X偏移")
        self.world_offset_y_input = QLineEdit(placeholderText="Y偏移")
        self.world_offset_z_input = QLineEdit(placeholderText="Z偏移")
        motion_layout.addWidget(self.world_offset_x_input, 2, 1)
        motion_layout.addWidget(self.world_offset_y_input, 2, 2)
        motion_layout.addWidget(self.world_offset_z_input, 2, 3)
        send_world_offset_button = QPushButton("发送世界偏移")
        send_world_offset_button.clicked.connect(self.send_descartes_point_offset)
        motion_layout.addWidget(send_world_offset_button, 2, 4)

        # 笛卡尔坐标走直线
        motion_layout.addWidget(QLabel("直线运动"), 3, 0)
        self.line_x_input = QLineEdit(placeholderText="X坐标")
        self.line_y_input = QLineEdit(placeholderText="Y坐标")
        self.line_z_input = QLineEdit(placeholderText="Z坐标")
        motion_layout.addWidget(self.line_x_input, 3, 1)
        motion_layout.addWidget(self.line_y_input, 3, 2)
        motion_layout.addWidget(self.line_z_input, 3, 3)
        send_line_button = QPushButton("发送直线运动")
        send_line_button.clicked.connect(self.send_descartes_line)
        motion_layout.addWidget(send_line_button, 3, 4)

        # 笛卡尔坐标直线偏移
        motion_layout.addWidget(QLabel("直线偏移"), 4, 0)
        self.line_offset_x_input = QLineEdit(placeholderText="X偏移")
        self.line_offset_y_input = QLineEdit(placeholderText="Y偏移")
        self.line_offset_z_input = QLineEdit(placeholderText="Z偏移")
        motion_layout.addWidget(self.line_offset_x_input, 4, 1)
        motion_layout.addWidget(self.line_offset_y_input, 4, 2)
        motion_layout.addWidget(self.line_offset_z_input, 4, 3)
        send_line_offset_button = QPushButton("发送直线偏移")
        send_line_offset_button.clicked.connect(self.send_descartes_linear_offset)
        motion_layout.addWidget(send_line_offset_button, 4, 4)

        # 吸嘴控制
        suction_label = QLabel("吸嘴")
        motion_layout.addWidget(suction_label, 5, 0)
        suction_on_button = QPushButton("吸嘴打开")
        suction_off_button = QPushButton("吸嘴关闭")
        suction_on_button.clicked.connect(self.send_suction_on)
        suction_off_button.clicked.connect(self.send_suction_off)
        motion_layout.addWidget(suction_on_button, 5, 1)
        motion_layout.addWidget(suction_off_button, 5, 2)

        # 回原点
        origin_button = QPushButton("回原点")
        origin_button.clicked.connect(self.send_origin)
        motion_layout.addWidget(origin_button, 6, 0)

        main_layout.addWidget(motion_area)

        # 设置中心窗口
        central_widget = QWidget()
        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)

    def list_serial_ports(self):
        """列出所有可用的串口"""
        ports = serial.tools.list_ports.comports()
        return [port.device for port in ports]

    def open_serial_port(self):
        """打开串口"""
        if self.port_combo.currentText():
            try:
                self.serial_port = serial.Serial(self.port_combo.currentText(), 9600, timeout=1)
                QMessageBox.information(self, "串口打开", "串口成功打开")
            except serial.SerialException as e:
                QMessageBox.critical(self, "串口错误", f"无法打开串口: {e}")
        else:
            QMessageBox.warning(self, "串口选择", "请选择一个串口")

    def close_serial_port(self):
        """关闭串口"""
        if self.serial_port:
            self.serial_port.close()
            self.serial_port = None
            QMessageBox.information(self, "串口关闭", "串口成功关闭")

    def send_joint_data(self):
        """发送关节数据"""
        if self.serial_port:
            try:
                x = float(self.joint_x_input.text())
                y = float(self.joint_y_input.text())
                z = float(self.joint_z_input.text())
                if not (-160 <= x <= 160 and -160 <= y <= 0 and -115 <= z <= 0):
                    raise ValueError("关节角度超出范围")
                command = f"JointAngle_{x},{y},{z},{self.sub_speed_slider.value()},\n"
                self.serial_port.write(command.encode())
                QMessageBox.information(self, "发送数据", "关节数据发送成功")
            except ValueError as e:
                QMessageBox.critical(self, "错误", str(e))
        else:
            QMessageBox.warning(self, "串口状态", "请先打开串口")

    def send_joint_offset_data(self):
        """发送关节角度偏移数据"""
        if self.serial_port:
            try:
                x = float(self.joint_offset_x_input.text())
                y = float(self.joint_offset_y_input.text())
                z = float(self.joint_offset_z_input.text())
                command = f"JointAngleOffset_{x},{y},{z},{self.sub_speed_slider.value()},\n"
                self.serial_port.write(command.encode())
                QMessageBox.information(self, "发送数据", "关节偏移数据发送成功")
            except ValueError as e:
                QMessageBox.critical(self, "错误", f"请输入有效数值: {e}")
        else:
            QMessageBox.warning(self, "串口状态", "请先打开串口")

    def send_descartes_point(self):
        """发送世界坐标数据（笛卡尔走点）"""
        if self.serial_port:
            try:
                x = float(self.world_x_input.text())
                y = float(self.world_y_input.text())
                z = float(self.world_z_input.text())
                command = f"DescartesPoint_{x},{y},{z},{self.sub_speed_slider.value()},\n"
                self.serial_port.write(command.encode())
                QMessageBox.information(self, "发送数据", "世界坐标数据发送成功")
            except ValueError as e:
                QMessageBox.critical(self, "错误", f"请输入有效数值: {e}")
        else:
            QMessageBox.warning(self, "串口状态", "请先打开串口")

    def send_descartes_point_offset(self):
        """发送世界坐标偏移数据"""
        if self.serial_port:
            try:
                x = float(self.world_offset_x_input.text())
                y = float(self.world_offset_y_input.text())
                z = float(self.world_offset_z_input.text())
                command = f"DescartesPointOffset_{x},{y},{z},{self.sub_speed_slider.value()},\n"
                self.serial_port.write(command.encode())
                QMessageBox.information(self, "发送数据", "世界偏移数据发送成功")
            except ValueError as e:
                QMessageBox.critical(self, "错误", f"请输入有效数值: {e}")
        else:
            QMessageBox.warning(self, "串口状态", "请先打开串口")

    def send_descartes_line(self):
        """发送直线运动数据"""
        if self.serial_port:
            try:
                x = float(self.line_x_input.text())
                y = float(self.line_y_input.text())
                z = float(self.line_z_input.text())
                command = f"DescartesLine_{x},{y},{z},{self.sub_speed_slider.value()},\n"
                self.serial_port.write(command.encode())
                QMessageBox.information(self, "发送数据", "直线运动数据发送成功")
            except ValueError as e:
                QMessageBox.critical(self, "错误", f"请输入有效数值: {e}")
        else:
            QMessageBox.warning(self, "串口状态", "请先打开串口")

    def send_descartes_linear_offset(self):
        """发送直线偏移数据"""
        if self.serial_port:
            try:
                x = float(self.line_offset_x_input.text())
                y = float(self.line_offset_y_input.text())
                z = float(self.line_offset_z_input.text())
                command = f"DescartesLinearOffset_{x},{y},{z},{self.sub_speed_slider.value()},\n"
                self.serial_port.write(command.encode())
                QMessageBox.information(self, "发送数据", "直线偏移数据发送成功")
            except ValueError as e:
                QMessageBox.critical(self, "错误", f"请输入有效数值: {e}")
        else:
            QMessageBox.warning(self, "串口状态", "请先打开串口")

    def send_suction_on(self):
        """打开吸嘴"""
        if self.serial_port:
            command = "Suction_1,\n"
            self.serial_port.write(command.encode())
            QMessageBox.information(self, "发送数据", "吸嘴打开指令发送成功")
        else:
            QMessageBox.warning(self, "串口状态", "请先打开串口")

    def send_suction_off(self):
        """关闭吸嘴"""
        if self.serial_port:
            command = "Suction_0,\n"
            self.serial_port.write(command.encode())
            QMessageBox.information(self, "发送数据", "吸嘴关闭指令发送成功")
        else:
            QMessageBox.warning(self, "串口状态", "请先打开串口")

    def send_origin(self):
        """发送回原点指令"""
        if self.serial_port:
            command = "Origin\n"
            self.serial_port.write(command.encode())
            QMessageBox.information(self, "发送数据", "回原点指令发送成功")
        else:
            QMessageBox.warning(self, "串口状态", "请先打开串口")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())