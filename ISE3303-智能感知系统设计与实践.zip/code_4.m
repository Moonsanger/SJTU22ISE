clear all;clc;close all;
P_real = [82.3,27.3,213,150,180];
thres = 0.0000001;
m2n = [-60.5,-41.1,-28.2,-42.4,-50.7,-37.5,-46.6,-33.1,-43.0,-29.3,-40.1,-26.0,-37.8,-13.8,-36.2];
m3n = [-64.4,-79.3,-86.4,-68.8,-57.8,-64.4,-53.9,-59.7,-49.5,-54.7,-44.7,-49.4,-39.5,-47.7,-34.0];
H0 = [160,170,180,190,200,210,220,230,240,250,260,270,280,290,300];
count = 0;
P = [80, 25, 200, 150, 200];
Ep = [1,1,1,1,1];
while (count <= 1000)
    fn_p1 = P(4)*cosd(P(1)+m2n);
    fn_p2 = P(5)*cosd(P(2)+m3n);
    fn_p3 = ones(size(H0));
    fn_p4 = sind(P(1)+m2n);
    fn_p5 = sind(P(2)+m3n);
    Jp = [fn_p1', fn_p2', fn_p3', fn_p4', fn_p5'];
    Z = P(3)+P(4)*sind(P(1)+m2n)+P(5)*sind(P(2)+m3n)-H0;
    Ez = 0 - Z';
    Ep_new = (Jp'*Jp)^(-1)*Jp'*Ez;
    SR = sum((Ep-Ep_new).^2);
    if SR <= thres*0.001
        break;
    end
    Ep = Ep_new;
    P = P+Ep';
    count = count + 1;
end

P
abs(P - P_real)
alpha2 = P(1);alpha3 = P(2);L1 = P(3); L2 = P(4);L3 = P(5);
