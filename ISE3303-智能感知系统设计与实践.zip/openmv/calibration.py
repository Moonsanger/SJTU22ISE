import sensor, image, time
from machine import UART

# 初始化摄像头
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)  # 320x240
sensor.skip_frames(time=2000)

# 关闭自动设置
sensor.set_auto_gain(False)
sensor.set_auto_whitebal(False)
sensor.set_auto_exposure(False, exposure_us=30000)

# 初始化串口通信
uart = UART(3, 115200)

# 优化参数配置
MIN_SIZE = 20           # 最小正方形边长（像素）
EDGE_THRESHOLD = 50     # 边缘检测阈值（调大减少噪点）
AREA_RATIO = 0.7        # 最小填充率（过滤镂空图形）

# 色块阈值配置（LAB色彩空间）
# Theshold L(0(black) ~ 100(white)) A(-128(green)~127(red)) B()
BLACK_THRESHOLD = (0, 50, -10, 10, -10, 10)
WHITE_THRESHOLD = (55, 100, -57, 26, -21, 56)
RED = (8, 100, 73, 37, -21, 56)    # 红色骰子（根据实际调整）
BLUE = (17, 100, 127, -88, -44, 95)   # 蓝色骰子（根据实际调整）


def send_command(cmd):
    # 发送指令
    uart.write(cmd + "\n")
    time.sleep(0.1)
    while uart.any():
        print(uart.readline())

def init_robot_arm():
    # 初始化机械臂
    send_command("Stop")
    send_command("Speed_50,")
    send_command("Origin")
    time.sleep(1)
    send_command("Suction_0,")
    time.sleep(1)

def move_to_standard_pos():
    # 第一步 ： 移动到指定位置  ！！！ 应该修改成走点
    # 世界坐标： 285 0 244.2  （原点： 255 0 444.2） （285.1 0 68.3（dice height））
    cmd = "DescartesPoint_285,0,244.2,50，"
    send_command(cmd)
    time.sleep(3)

standard_pos = [108, 65]
des_pos = [200, 100]
height = 100
dice_height = 15

def align(standard_pos, dice_pos):
    scale_x = 2.4
    scale_y = 3.2
    bias_x = 10
    bias_y = 40
    # x_t = standard_pos[0]
    # y_t = standard_pos[1]
    dx = int((standard_pos[0] - dice_pos[0])/scale_x) - bias_x
    dy = int((standard_pos[1] - dice_pos[1])/scale_y) - bias_y
    cmd = f"DescartesPointOffset_{dx},{dy},0,50"
    print(cmd)
    send_command(cmd)
    time.sleep(1)

def suck_dice():
    # 下降
    cmd_1 = "DescartesPointOffset_0,0,-178,50"
    send_command(cmd=cmd_1)
    time.sleep(1)
    # 启动吸嘴
    cmd_2 = "Suction_1,"
    send_command(cmd_2)
    time.sleep(1)
    # 回到标准位置
    move_to_standard_pos()
    time.sleep(1)
# 世界坐标： 285 0 244.2
# init_robot_arm()
# time.sleep(2)
move_to_standard_pos()
# send_command("DescartesPoint_285,0,244.2,50，")
# align(standard_pos, [200, 100])
# time.sleep(2)
# suck_dice()
# time.sleep(2)
# send_command("Suction_0,")
step = 18
height = -180
cmd = f"DescartesPointOffset_0,0,{height+step},50"
send_command(cmd)
time.sleep(1)
send_command("Suction_1,")
time.sleep(3)
send_command("Suction_0,")



clock = time.clock()

# while True:
#     clock.tick()
#     img = sensor.snapshot()
    # print(clock.fps())
