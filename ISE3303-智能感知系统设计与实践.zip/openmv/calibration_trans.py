import sensor, image, time, math
from machine import UART

# 初始化摄像头
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)  # 320x240
sensor.skip_frames(time=2000)

# 关闭自动设置
sensor.set_auto_gain(False)
sensor.set_auto_whitebal(False)
sensor.set_auto_exposure(False, exposure_us=80000)

# 初始化串口通信
uart = UART(3, 115200)

# 优化参数配置
MIN_SIZE = 20           # 最小正方形边长（像素）
EDGE_THRESHOLD = 50     # 边缘检测阈值（调大减少噪点）
AREA_RATIO = 0.7        # 最小填充率（过滤镂空图形）

# 色块阈值配置（LAB色彩空间）
WHITE_THRESHOLD = (78, 100, 2, -45, -52, 80)
RED = (19, 66, 82, 10, 62, 10)    # 红色骰子（根据实际调整）
BLUE = (11, 42, -11, 100, -99, -28)   # 蓝色骰子（根据实际调整）

# 骰子检测参数
DICE_MAX_DISTANCE = 30  # 两个色块最大距离（像素），超过则认为是不同骰子
MIN_DOTS_PER_DICE = 1   # 每个骰子至少有几个点（避免误检）

def send_command(cmd):
    # 发送指令
    uart.write(cmd + "\n")
    time.sleep(0.1)
    while uart.any():
        print(uart.readline())

def init_robot_arm():
    # 初始化机械臂
    send_command("Suction_0,")
    send_command("Stop")
    time.sleep(0.1)
    send_command("Speed_50,")
    time.sleep(0.1)
    send_command("Origin")
    time.sleep(1)
    send_command("Suction_0,")
    time.sleep(1)

def move_to_standard_pos():
    # 第一步 ： 移动到指定位置  ！！！ 应该修改成走点
    # 世界坐标： 285 0 244.2  （原点： 255 0 444.2） （285.1 0 68.3（dice height））
    cmd = "DescartesPoint_285,0,244.2,50，"
    send_command(cmd)
    time.sleep(3)

dice_pos =  [(216, 90), (58, 76), (137, 83)] #[1, 3, 2]
standard_pos = [108, 65]

def align(standard_pos, dice_pos):
    scale_x = 2
    scale_y = 2
    bias_x = 10
    bias_y = 10
    # x_t = standard_pos[0]
    # y_t = standard_pos[1]
    dx = int((standard_pos[0] - dice_pos[0])/scale_x) - bias_x
    dy = int((standard_pos[1] - dice_pos[1])/scale_y) - bias_y
    cmd = f"DescartesPointOffset_{dx},{dy},0,50"
    print(cmd)
    send_command(cmd)
    time.sleep(1)

move_to_standard_pos()

cmd = f"DescartesPointOffset_-48,-8,0,50"
print(cmd)
send_command(cmd)
time.sleep(1)

cmd_1 = "DescartesPointOffset_0,0,-178,50"
send_command(cmd=cmd_1)
time.sleep(1)

# move_to_standard_pos()


# clock = time.clock()
# while True:
#     clock.tick()
#     img = sensor.snapshot()
