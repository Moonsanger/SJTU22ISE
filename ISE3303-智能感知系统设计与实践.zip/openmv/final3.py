import sensor, image, time, math
from machine import UART

# 初始化摄像头
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)  # 320x240
sensor.skip_frames(time=2000)

# 关闭自动设置
sensor.set_auto_gain(False)
sensor.set_auto_whitebal(False)

################################ 根绝不同的背景进行调节的指标 ####################################
sensor.set_auto_exposure(False, exposure_us=80000)
# 色块阈值配置（LAB色彩空间）
WHITE_THRESHOLD = (78, 100, 2, -45, -52, 80)
RED = (19, 66, 82, 10, 62, 10)    # 红色骰子（根据实际调整）
BLUE = (0, 59, -89, 127, -128, -32)   # 蓝色骰子（根据实际调整）
# 黑色背景
# WHITE_THRESHOLD = (55, 100, -128, 127, -128, 127)
# RED = (19, 66, 82, 13, -128, 127)    # 红色骰子（根据实际调整）
# BLUE = (0, 100, -96, 117, -95, -18)  # 蓝色骰子（根据实际调整）

# 初始化串口通信
uart = UART(3, 115200)

################################# 标定点不同高度需要改变以下量 ###############################
# 机械臂标准点位置
X_ori = 285
Y_ori = 0
Z_ori = 344.2          #！！！！！！！！！！！
# Z_inti = 444.2
# dice目标点位置
X_des = 30
Y_des = 120

# 从标准点下降到能够吸附dice的dz
Z_dz = - Z_ori + 65

# 骰子大小
DICE_SIZE = 18  # 骰子大小（mm），根据实际情况进行调整

# 骰子检测参数
DICE_MAX_DISTANCE = 15  # 两个色块最大距离（像素），超过则认为是不同骰子
MIN_DOTS_PER_DICE = 1   # 每个骰子至少有几个点（避免误检）

# 三点坐标变换矩阵  （下节课首先就得测量出来）
# H = [[ 0.07774538, -0.83090379,  9.83770651], [-0.58843537,  0.13265306, 53.77210884]]
# H = [[-1.10281039e-02,-5.70437567e-01,3.78637496e+00], [-5.95161864e-01,  3.73532551e-02,  6.68582355e+01]]
# H = [[  0.13948384,   0.29521355, -68.45056737], [ -0.63927344,   0.30882909,  47.60602417]]
H = [[ 4.28527701e-02, -6.94827058e-01,  4.49035813e+00],
[-6.38200184e-01, -9.18273646e-03,  6.77685950e+01]]
######################################    FUNCTION   ################################################
def send_command(cmd):
    # 发送指令
    uart.write(cmd + "\n")
    time.sleep(0.1)
    while uart.any():
        print(uart.readline())

def init_robot_arm():
    # 初始化机械臂
    print("***************init robot arm****************")
    send_command("Suction_0,")
    send_command("Stop")
    time.sleep(0.5)
    send_command("Speed_100,")
    time.sleep(0.5)
    send_command("Origin")
    time.sleep(0.5)
    send_command("Suction_0,")
    time.sleep(0.5)
    print("***************init robot arm finished****************")

def move_to_standard_pos():
    # 第一步 ： 移动到指定位置  ！！！ 应该修改成走点
    # 世界坐标：   X_ori = 285 Y_ori = 0 Z_ori = 344.2 （原点： 255 0 444.2）
    # 285.1 0 68.3（dice height））
    print("***************move to standard pos****************")
    cmd = f"DescartesPoint_{X_ori},{Y_ori},{Z_ori},100，"                          #            拍照的高度越高越好
    send_command(cmd)
    time.sleep_ms(200)
    # send_command("Suction_0,")
    # time.sleep_ms(200)
    print("***************move to standard pos finished****************")

def move_to_sec_place():
    cmd = f"DescartesPoint_{X_ori},{Y_ori},{Z_ori-200},100，"                          #            拍照的高度越高越好
    send_command(cmd)
    time.sleep_ms(200)

def detect_all_dice(max_detection=5, timeout=2000):
    """
    检测所有骰子的位置和点数
    参数:
        max_detection: 最大检测次数
        timeout: 超时时间(ms)
    返回:
        (all_dice_pos, all_dice_num)
        all_dice_pos: 所有骰子中心位置列表 [(x1,y1), (x2,y2), ...]
        all_dice_num: 所有骰子点数列表 [num1, num2, ...]
    """
    print("***************detect all dice****************")
    all_dice_pos = []
    all_dice_num = []
    start_time = time.ticks_ms()
    detection_count = 0

    while detection_count < max_detection and time.ticks_diff(time.ticks_ms(), start_time) < timeout:
        img = sensor.snapshot().lens_corr(strength = 1.8, zoom = 1.0)  #要根据实际情况进行调节，其中strength确定对图像去鱼眼效果的程度

        # 清空临时列表
        temp_pos = []
        temp_num = []

        # 检测色块
        blue_blobs = img.find_blobs([BLUE], x_stride=1, y_stride=1, area_threshold=0, merge=False)
        # print(len(blue_blobs))
        red_blobs = img.find_blobs([RED], x_stride=1, y_stride=1, area_threshold=0, merge=False)
        # print(len(red_blobs))
        # 分组色块的通用函数
        def group_blobs(blobs):
            groups = []
            for blob in blobs:
                matched = False
                for group in groups:
                    for b in group:
                        if math.sqrt((blob.cx()-b.cx())**2 + (blob.cy()-b.cy())**2) < DICE_MAX_DISTANCE:
                            group.append(blob)
                            matched = True
                            break
                    if matched: break
                if not matched:
                    groups.append([blob])
            return [g for g in groups if len(g) >= MIN_DOTS_PER_DICE]

        # 处理红色骰子
        red_groups = group_blobs(red_blobs)
        for group in red_groups:
            center_x = sum(b.cx() for b in group) // len(group)
            center_y = sum(b.cy() for b in group) // len(group)
            temp_pos.append((center_x, center_y))
            temp_num.append(len(group))
            # 绘制红色骰子
            img.draw_rectangle(
                min(b.x() for b in group), min(b.y() for b in group),
                max(b.x()+b.w() for b in group)-min(b.x() for b in group),
                max(b.y()+b.h() for b in group)-min(b.y() for b in group),
                color=(255,0,0)
            )
            img.draw_string(center_x, center_y-10, str(len(group)), color=(255,255,255))

        # 处理蓝色骰子
        blue_groups = group_blobs(blue_blobs)
        for group in blue_groups:
            center_x = sum(b.cx() for b in group) // len(group)
            center_y = sum(b.cy() for b in group) // len(group)
            temp_pos.append((center_x, center_y))
            temp_num.append(len(group))
            # 绘制蓝色骰子
            img.draw_rectangle(
                min(b.x() for b in group), min(b.y() for b in group),
                max(b.x()+b.w() for b in group)-min(b.x() for b in group),
                max(b.y()+b.h() for b in group)-min(b.y() for b in group),
                color=(0,0,255)
            )
            img.draw_string(center_x, center_y-10, str(len(group)), color=(255,255,255))

        # 更新最终结果
        all_dice_pos = temp_pos
        all_dice_num = temp_num

        detection_count += 1
        time.sleep_ms(100)  # 避免过于频繁检测
    print("***************detect all dice finished****************")
    return all_dice_pos, all_dice_num

# X_des = 30
# Y_des = 120
def move_dice_to_des(dice_pos, height):
    """移动骰子到指定位置
    参数:
        dice_pos: 骰子位置 (x, y)
        height: 下降高度
    """
    dx = H[0][0]*dice_pos[0] + H[0][1]*dice_pos[1] + H[0][2]
    dy = H[1][0]*dice_pos[0] + H[1][1]*dice_pos[1] + H[1][2]
    dz = Z_dz + 200
    print(f"继续移动{dx}, {dy},{dz}")
    time.sleep(0.5)
    send_command(f"DescartesPointOffset_{dx},{dy},{dz},100")
    time.sleep(0.5)
    send_command("Suction_1,")
    time.sleep(0.5)

    move_to_sec_place()
    time.sleep(0.5)

    send_command(f"DescartesPointOffset_{X_des},{Y_des},0,100")
    time.sleep_ms(1000)

    send_command("Suction_0,")
    time.sleep(0.5)

    move_to_sec_place()
    time.sleep(0.5)

def move_dice():
    """
        在状态不变的情况下，能够按照顺序搬运dice到指定的位置
        按照点数的大小顺序进行骰子的搬运，最后叠放在des pos目标点上
    """
    print("GO GO GO 出发咯！按照dice点数大小顺序进行搬运")
    # init_robot_arm()
    # time.sleep(1)
    move_to_standard_pos()
    dice_pos, dice_num = detect_all_dice()

    print(f"一共有{dice_num}个骰子，位置为",dice_pos)
    time.sleep(1)
    move_to_sec_place()

    for i in range(len(dice_num)):
        print(f"现在移动的是点数为{dice_num[i]}，位置为{dice_pos[i]}的骰子")
        move_dice_to_des(dice_pos[i], Z_dz)
        print(f"点数为{dice_num[i]}的骰子已经搬运完成")

    print(" ALL DICE MOVE FINISHED!")

def main():
    # 主函数
    # calibration: 1.先将骰子放在一定的地方（可以得到像素坐标）
    # init_robot_arm()
    # time.sleep(1)
    move_to_standard_pos()
    time.sleep(1)
    send_command(f"DescartesPointOffset_-28.0, -89.8,{Z_dz-2},50")
    time.sleep(1)
    # (-30, -40)->(168, 60)  (-50,30) -> (58, 82)  (0,0)->(106, 13)
    send_command("Suction_1,")
    time.sleep(1)
    send_command("Suction_0,")

def calibration():
    move_to_standard_pos()
    time.sleep(1)
    move_to_standard_pos()
    dice_pos, dice_num = detect_all_dice()
    print(f"一共有{dice_num}个骰子，位置为",dice_pos)


if __name__ == "__main__":
    # main()
    # calibration()
    # move_dice_in_order()
    # send_command("Suction_1,")
    # time.sleep(0.5)
    # init_robot_arm()
    # move_to_sec_place()
    move_dice()
    # move_to_standard_pos()
    # time.sleep(1)
    # dice_pos, dice_num = detect_all_dice()

    # print(f"一共有{dice_num}个骰子，位置为",dice_pos)
    # move_to_sec_place()
    # dice_pos = dice_pos[0]
    # dx = H[0][0]*dice_pos[0] + H[0][1]*dice_pos[1] + H[0][2]
    # dy = H[1][0]*dice_pos[0] + H[1][1]*dice_pos[1] + H[1][2]
    # dz = Z_dz + 250

    # print(f"继续移动{dx}, {dy},{dz}")
    # time.sleep(1)
    # send_command(f"DescartesPointOffset_{dx},{dy},{dz},100")


