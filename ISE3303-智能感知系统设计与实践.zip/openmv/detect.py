import sensor, image, time, math
from machine import UART

# 初始化摄像头
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)  # 320x240
sensor.skip_frames(time=2000)

# 关闭自动设置
sensor.set_auto_gain(False)
sensor.set_auto_whitebal(False)
sensor.set_auto_exposure(False, exposure_us=80000)

# 初始化串口通信
uart = UART(3, 115200)

def send_command(cmd):
    # 发送指令
    uart.write(cmd + "\n")
    time.sleep(0.1)
    while uart.any():
        print(uart.readline())

def init_robot_arm():
    # 初始化机械臂
    send_command("Stop")
    send_command("Speed_50,")
    send_command("Origin")
    time.sleep(1)
    send_command("Suction_0,")
    time.sleep(1)

def move_to_standard_pos():
    # 第一步 ： 移动到指定位置  ！！！ 应该修改成走点
    # 世界坐标： 285 0 244.2  （原点： 255 0 444.2） （285.1 0 68.3（dice height））
    cmd = "DescartesPoint_285,0,244.2,50，"
    send_command(cmd)
    time.sleep(3)


# init_robot_arm()
# move_to_standard_pos()

standard_pos = [108, 65]
des_pos = [200, 100]
height = 180
dice_height = 18

# 色块阈值配置（LAB色彩空间）
WHITE_THRESHOLD = (78, 100, 2, -45, -52, 80)
RED = (19, 66, 82, 10, 62, 10)    # 红色骰子（根据实际调整）
BLUE = (11, 42, -11, 100, -99, -28)   # 蓝色骰子（根据实际调整）

clock = time.clock()

# 骰子检测参数
DICE_MAX_DISTANCE = 30  # 两个色块最大距离（像素），超过则认为是不同骰子
MIN_DOTS_PER_DICE = 1   # 每个骰子至少有几个点（避免误检）


def detect_all_dice(max_detection=5, timeout=2000):
    """
    检测所有骰子的位置和点数
    参数:
        max_detection: 最大检测次数
        timeout: 超时时间(ms)
    返回:
        (all_dice_pos, all_dice_num)
        all_dice_pos: 所有骰子中心位置列表 [(x1,y1), (x2,y2), ...]
        all_dice_num: 所有骰子点数列表 [num1, num2, ...]
    """
    all_dice_pos = []
    all_dice_num = []
    start_time = time.ticks_ms()
    detection_count = 0

    while detection_count < max_detection and time.ticks_diff(time.ticks_ms(), start_time) < timeout:
        img = sensor.snapshot()

        # 清空临时列表
        temp_pos = []
        temp_num = []

        # 检测色块
        blue_blobs = img.find_blobs([BLUE], x_stride=2, y_stride=2, area_threshold=10, merge=False)
        red_blobs = img.find_blobs([RED], x_stride=2, y_stride=2, area_threshold=10, merge=False)

        # 分组色块的通用函数
        def group_blobs(blobs):
            groups = []
            for blob in blobs:
                matched = False
                for group in groups:
                    for b in group:
                        if math.sqrt((blob.cx()-b.cx())**2 + (blob.cy()-b.cy())**2) < DICE_MAX_DISTANCE:
                            group.append(blob)
                            matched = True
                            break
                    if matched: break
                if not matched:
                    groups.append([blob])
            return [g for g in groups if len(g) >= MIN_DOTS_PER_DICE]

        # 处理红色骰子
        red_groups = group_blobs(red_blobs)
        for group in red_groups:
            center_x = sum(b.cx() for b in group) // len(group)
            center_y = sum(b.cy() for b in group) // len(group)
            temp_pos.append((center_x, center_y))
            temp_num.append(len(group))
            # 绘制红色骰子
            img.draw_rectangle(
                min(b.x() for b in group), min(b.y() for b in group),
                max(b.x()+b.w() for b in group)-min(b.x() for b in group),
                max(b.y()+b.h() for b in group)-min(b.y() for b in group),
                color=(255,0,0)
            )
            img.draw_string(center_x, center_y-10, str(len(group)), color=(255,255,255))

        # 处理蓝色骰子
        blue_groups = group_blobs(blue_blobs)
        for group in blue_groups:
            center_x = sum(b.cx() for b in group) // len(group)
            center_y = sum(b.cy() for b in group) // len(group)
            temp_pos.append((center_x, center_y))
            temp_num.append(len(group))
            # 绘制蓝色骰子
            img.draw_rectangle(
                min(b.x() for b in group), min(b.y() for b in group),
                max(b.x()+b.w() for b in group)-min(b.x() for b in group),
                max(b.y()+b.h() for b in group)-min(b.y() for b in group),
                color=(0,0,255)
            )
            img.draw_string(center_x, center_y-10, str(len(group)), color=(255,255,255))

        # 更新最终结果
        all_dice_pos = temp_pos
        all_dice_num = temp_num

        detection_count += 1
        time.sleep_ms(100)  # 避免过于频繁检测

    return all_dice_pos, all_dice_num


dice_pos, dice_num = detect_all_dice()
print(dice_pos)
print(dice_num)

# dice_pos = []

# while True:
#     img = sensor.snapshot()

#     # 1. 检测所有蓝色色块
#     blue_blobs = img.find_blobs(
#         [BLUE],
#         x_stride=2,
#         y_stride=2,
#         area_threshold=10,
#         merge=False,  # 不自动合并，我们自己判断
#     )
#     red_blobs = img.find_blobs(
#         [RED],
#         x_stride=2,
#         y_stride=2,
#         area_threshold=10,
#         merge=False,  # 不自动合并，我们自己判断
#     )

#     # 2. 分组：判断哪些色块属于同一个骰子
#     dice_list_red = []  # 存储每个骰子的信息：[ [blob1, blob2, ...], ... ]
#     dice_list_blue = []

#     for blob in blue_blobs:
#         matched = False

#         # 检查是否和已有的骰子匹配
#         for dice in dice_list_blue:
#             for existing_blob in dice:
#                 # 计算两个色块中心距离
#                 distance = math.sqrt(
#                     (blob.cx() - existing_blob.cx()) ** 2 +
#                     (blob.cy() - existing_blob.cy()) ** 2
#                 )

#                 # 如果距离足够近，则归入同一个骰子
#                 if distance < DICE_MAX_DISTANCE:
#                     dice.append(blob)
#                     matched = True
#                     break

#             if matched:
#                 break

#         # 如果没有匹配到任何骰子，则新建一个骰子组
#         if not matched:
#             dice_list_blue.append([blob])

#     for blob in red_blobs:
#         matched = False

#         # 检查是否和已有的骰子匹配
#         for dice in dice_list_red:
#             for existing_blob in dice:
#                 # 计算两个色块中心距离
#                 distance = math.sqrt(
#                     (blob.cx() - existing_blob.cx()) ** 2 +
#                     (blob.cy() - existing_blob.cy()) ** 2
#                 )

#                 # 如果距离足够近，则归入同一个骰子
#                 if distance < DICE_MAX_DISTANCE:
#                     dice.append(blob)
#                     matched = True
#                     break

#             if matched:
#                 break

#         # 如果没有匹配到任何骰子，则新建一个骰子组
#         if not matched:
#             dice_list_red.append([blob])

#     # 3. 过滤掉点数太少的骰子（可能是噪点）
#     valid_dice_blue = [dice for dice in dice_list_blue if len(dice) >= MIN_DOTS_PER_DICE]
#     valid_dice_red = [dice for dice in dice_list_red if len(dice) >= MIN_DOTS_PER_DICE]

#     valid_dice = valid_dice_blue + valid_dice_red

#     # 4. 计算每个骰子的中心位置和点数
#     for dice in valid_dice:
#         # 计算骰子中心（取所有色块的平均位置）
#         center_x = sum([blob.cx() for blob in dice]) // len(dice)
#         center_y = sum([blob.cy() for blob in dice]) // len(dice)

#         # 绘制骰子边界（所有色块的最小外接矩形）
#         min_x = min([blob.x() for blob in dice])
#         min_y = min([blob.y() for blob in dice])
#         max_x = max([blob.x() + blob.w() for blob in dice])
#         max_y = max([blob.y() + blob.h() for blob in dice])
#         width = max_x - min_x
#         height = max_y - min_y

#         img.draw_rectangle(min_x, min_y, width, height, color=(0, 255, 0))
#         img.draw_cross(center_x, center_y, color=(255, 0, 0))

#         # 显示骰子点数
#         img.draw_string(center_x, center_y - 10, f"{len(dice)}", color=(255, 255, 255))

#         # 输出调试信息
#         print(f"骰子位置: ({center_x}, {center_y}), 点数: {len(dice)}")





